<?php

class adminDashboard extends CI_Controller{

    function index()
    {
        $this->load->view('admin/dashboard');
    }

    function signOut()
    {
            $this->session->unset_userdata('user');
            redirect(base_url().'login');
    }

}

?>