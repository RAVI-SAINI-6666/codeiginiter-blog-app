<?php
class Home extends CI_Controller
{
        public function index()
        {
            $data = array();
            $this->load->model('Blog_model');
            $allBlogs = $this->Blog_model->getAllBlogs();

            $featuredBlogs = $this->Blog_model->getFeaturedBlogs();
            $promoBlogs = $this->Blog_model->getPromoBlogs();

            $data['allBlogs'] = $allBlogs;
            $data['featuredBlogs'] = $featuredBlogs;
            $data['promoBlogs'] = $promoBlogs;
            
            $this->load->view('home',$data);
        }   

        function blogDetail($blogId)
        {
            $this->load->model('Blog_model');
            $this->load->model('Comment_model');
          $blog =  $this->Blog_model->getBlog($blogId);
            if(empty($blog)){
                redirect(base_url());
            }
            $data = array();
            $data['blog'] = $blog;

            $comments = $this->Comment_model->getCommentBlog($blogId);
            $data['comments'] = $comments;

            $this->form_validation->set_rules('name','Name','required');
            $this->form_validation->set_rules('comment','Comment','required');
        if($this->form_validation->run() == true)
        {
            $formArray = array();
            $formArray['name'] = $this->input->post('name');
            $formArray['Blog_id'] = $blogId;
            $formArray['comment'] = $this->input->post('comment');
            $formArray['created_at'] = date('Y-m-d');
            $this->Comment_model->create($formArray);

            $this->session->set_flashdata('msg','Comment Saved Successfully');
            redirect(base_url().'home/blogDetail/'.$blog['blog_id']);
        }else{
            $this->load->view('detail',$data);
        }
        }
 
        

}




?>